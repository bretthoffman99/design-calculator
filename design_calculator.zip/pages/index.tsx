import DesignCalculator from "../components/DesignCalculator";

export default function Home() {
  return (
    <main className="p-6">
      <DesignCalculator />
    </main>
  );
}